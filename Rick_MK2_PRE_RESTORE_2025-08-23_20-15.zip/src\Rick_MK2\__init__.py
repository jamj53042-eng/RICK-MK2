from .rick import RickMK2
__all__ = ["RickMK2"]
