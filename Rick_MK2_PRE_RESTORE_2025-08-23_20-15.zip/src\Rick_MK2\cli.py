from __future__ import annotations
import argparse, sys
from .rick import RickMK2
from .templates import reset_prompt, undo_feedback

def main(argv: list[str] | None = None) -> int:
    argv = argv or sys.argv[1:]

    parser = argparse.ArgumentParser(prog="Rick_MK2", add_help=True)
    sub = parser.add_subparsers(dest="cmd")

    # status
    p_status = sub.add_parser("status", help="Show status. Add optional: daily|weekly|full")
    p_status.add_argument("mode", nargs="?", choices=["daily", "weekly", "full"], default=None)

    # log
    p_log = sub.add_parser("log", help="Add a manual log entry (wrap in quotes)")
    p_log.add_argument("text", nargs="+")

    # undo
    p_undo = sub.add_parser("undo", help="Remove last N log entries (default 1)")
    p_undo.add_argument("n", nargs="?", type=int, default=1)

    # reset
    p_reset = sub.add_parser("reset", help="Reset streak|log|all (asks for confirmation)")
    p_reset.add_argument("scope", choices=["streak", "log", "all"])

    # help (alias)
    sub.add_parser("help", help="Show help")

    args = parser.parse_args(argv)

    if args.cmd in (None, "help"):
        parser.print_help()
        return 0

    rick = RickMK2()

    if args.cmd == "status":
        print(rick.status(args.mode))
        return 0

    if args.cmd == "log":
        text = " ".join(args.text)
        rick.log(text)
        print("Logged.")
        return 0

    if args.cmd == "undo":
        n = args.n if args.n and args.n > 0 else 1
        rick.undo(n)
        print(undo_feedback(n))
        return 0

    if args.cmd == "reset":
        scope = args.scope
        print(reset_prompt("EVERYTHING (streak, log, bonuses)" if scope == "all" else scope))
        confirm = input("> ").strip()
        if confirm.upper() != "YES":
            print("Cancelled.")
            return 0
        rick.reset(scope)
        print("Reset complete.")
        return 0

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
