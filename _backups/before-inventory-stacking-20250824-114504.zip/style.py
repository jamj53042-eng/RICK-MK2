class RickStyle:
    def say(self, text):
        print(text)
