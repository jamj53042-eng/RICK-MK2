def add_log(entry: str):
    print(f"[Log] Added entry: {entry}")
