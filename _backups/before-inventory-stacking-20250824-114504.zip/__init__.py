# Rick package init
