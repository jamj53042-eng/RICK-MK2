# Rick_MK2 package initializer
# Expose CLI entrypoint
from .rick import main

__all__ = ["main"]
