from __future__ import annotations
from typing import Tuple
from datetime import datetime, timezone
from .storage import Storage

storage = Storage()

def _today_key() -> str:
    return datetime.now(timezone.utc).astimezone().date().isoformat()

def gain_xp(amount: int) -> Tuple[int, int, int, int]:
    data = storage.load()
    last_update = data.get("last_update")
    today = _today_key()
    if last_update != today:
        data["streak"] = (data.get("streak", 0) or 0) + 1
        data["best_streak"] = max(data.get("best_streak", 0) or 0, data["streak"])
        data["last_update"] = today
    bonus_per_streak = data.get("bonus_per_streak", 5)
    cap = data.get("bonus_cap", 100)
    bonus = min(cap, data["streak"] * bonus_per_streak)
    total_gain = amount + bonus
    data["xp"] = (data.get("xp", 0) or 0) + total_gain
    data["level"] = 1 + data["xp"] // 100
    storage.save(data)
    return data["xp"], data["level"], data["streak"], data["best_streak"]
