from __future__ import annotations
from typing import Any, Tuple
import random
from .storage import Storage

storage = Storage()

def _ensure(data: dict) -> None:
    if "inventory" not in data or not isinstance(data["inventory"], list):
        data["inventory"] = []
    if "gold" not in data or not isinstance(data["gold"], int):
        data["gold"] = 0

def list_items() -> Tuple[list[dict[str, Any]], int]:
    data = storage.load()
    _ensure(data)
    return data["inventory"], data["gold"]

def add_item(name: str, qty: int = 1, rarity: str = "common") -> dict[str, Any]:
    data = storage.load()
    _ensure(data)
    inv = data["inventory"]
    for it in inv:
        if it.get("name").lower() == name.lower():
            it["qty"] = int(it.get("qty", 0)) + qty
            storage.save(data)
            return it
    item = {"name": name, "qty": qty, "rarity": rarity}
    inv.append(item)
    storage.save(data)
    return item

def remove_item(name: str, qty: int = 1) -> bool:
    data = storage.load()
    _ensure(data)
    inv = data["inventory"]
    for it in inv:
        if it.get("name").lower() == name.lower():
            it["qty"] = int(it.get("qty", 0)) - qty
            if it["qty"] <= 0:
                inv.remove(it)
            storage.save(data)
            return True
    return False

def add_gold(amount: int) -> int:
    data = storage.load()
    _ensure(data)
    data["gold"] += amount
    storage.save(data)
    return data["gold"]

def roll_challenge_loot(difficulty: str) -> list[str]:
    difficulty = difficulty.lower()
    msgs: list[str] = []
    if difficulty == "easy":
        if random.random() < 0.6:
            add_item("Healing Potion", 1, "common")
            msgs.append("Found 1x Healing Potion")
        if random.random() < 0.5:
            from random import randint
            g = randint(5, 15)
            add_gold(g)
            msgs.append(f"Gained {g} gold")
    elif difficulty == "hard":
        from random import randint
        g = randint(15, 40)
        add_gold(g)
        msgs.append(f"Gained {g} gold")
        if random.random() < 0.7:
            add_item("Healing Potion", randint(1, 3), "common")
            msgs.append("Found Healing Potions")
        if random.random() < 0.3:
            add_item("Iron Sword", 1, "uncommon")
            msgs.append("Looted Iron Sword")
    else:
        if random.random() < 0.3:
            add_gold(5)
            msgs.append("Gained 5 gold")
    return msgs
