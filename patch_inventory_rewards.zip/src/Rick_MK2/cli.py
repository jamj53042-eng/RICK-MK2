from __future__ import annotations
import click
from .storage import Storage
from .journal import (
    log_entry,
    search_entries_by_tag,
    update_entry,
    remove_entry,
    clear_entries_by_tag,
    clear_all_entries,
)
from .quest import (
    add_quest, list_quests, complete_quest, delete_quest, clear_quests
)
from .xp import gain_xp
from .inventory import list_items as inv_list, add_item as inv_add, remove_item as inv_remove, roll_challenge_loot

@click.group()
def main():
    """Rick MK2 CLI"""

@main.command()
@click.option("--compact", is_flag=True, help="Compact timeline view.")
def status(compact: bool):
    data = Storage().load()
    logs = data.get("logs", [])
    if compact:
        for e in logs:
            click.echo(f'{e.get("timestamp")} [{e.get("tag")}] {e.get("text")}')
    else:
        for e in logs:
            click.echo(f'{e.get("id")}: {e.get("timestamp")} [{e.get("tag")}] {e.get("text")}')

@main.command()
@click.argument("text")
@click.option("--tag", required=True, help="Tag for the entry.")
def log(text: str, tag: str):
    entry = log_entry(text, tag)
    click.echo(f'{entry["id"]}: {entry["timestamp"]} [{entry["tag"]}] {entry["text"]}')

@main.command()
@click.option("--tag", required=True, help="Filter by tag.")
def search(tag: str):
    results = search_entries_by_tag(tag)
    for e in results:
        click.echo(f'{e.get("id")}: {e.get("timestamp")} [{e.get("tag")}] {e.get("text")}')

@main.command()
@click.argument("entry_id", type=int)
@click.option("--text", default=None, help="New text.")
@click.option("--tag", "new_tag", default=None, help="New tag.")
def edit(entry_id: int, text: str | None, new_tag: str | None):
    ok = update_entry(entry_id, text, new_tag)
    if ok:
        click.echo(f"Updated {entry_id}.")
    else:
        click.echo(f"Entry {entry_id} not found.", err=True)
        raise SystemExit(1)

@main.command()
@click.argument("entry_id", type=int)
def delete(entry_id: int):
    ok = remove_entry(entry_id)
    if ok:
        click.echo(f"Deleted {entry_id}.")
    else:
        click.echo(f"Entry {entry_id} not found.", err=True)
        raise SystemExit(1)

@main.command()
@click.option("--tag", "tag", default=None, help="Remove all entries with this tag.")
@click.option("--all", "all_", is_flag=True, help="Remove ALL entries.")
def clear(tag: str | None, all_: bool):
    if (tag is None and not all_) or (tag is not None and all_):
        raise click.UsageError("Use either --tag <tag> OR --all.")
    if tag:
        n = clear_entries_by_tag(tag)
        click.echo(f'Removed {n} entr{"y" if n==1 else "ies"} with tag "{tag}".')
    else:
        n = clear_all_entries()
        click.echo(f"Removed {n} entr{'y' if n==1 else 'ies'}." )

@main.group()
def quest():
    """Quest management"""

@quest.command("add")
@click.argument("title")
@click.option("--desc", required=True, help="Quest description.")
def quest_add(title: str, desc: str):
    q = add_quest(title, desc)
    click.echo(f"{q['id']}: [active] {q['title']} - {q['desc']}")

@quest.command("list")
@click.option("--active", is_flag=True, help="Show only active quests.")
@click.option("--done", is_flag=True, help="Show only completed quests.")
def quest_list(active: bool, done: bool):
    status = None
    if active and not done:
        status = "active"
    elif done and not active:
        status = "done"
    rows = list_quests(status)
    for q in rows:
        if q.get("status") == "done":
            click.echo(f"{q['id']}: [done] {q['title']} (completed {q.get('completed')}) - {q['desc']}")
        else:
            click.echo(f"{q['id']}: [active] {q['title']} - {q['desc']}")

@quest.command("complete")
@click.argument("qid", type=int)
def quest_complete(qid: int):
    if complete_quest(qid):
        click.echo(f"Completed quest {qid}.")
    else:
        click.echo(f"Quest {qid} not found or already done.", err=True)
        raise SystemExit(1)

@quest.command("delete")
@click.argument("qid", type=int)
def quest_delete(qid: int):
    if delete_quest(qid):
        click.echo(f"Deleted quest {qid}.")
    else:
        click.echo(f"Quest {qid} not found.", err=True)
        raise SystemExit(1)

@quest.command("clear")
@click.option("--all", is_flag=True, help="Remove ALL quests.")
def quest_clear(all: bool):
    if not all:
        raise click.UsageError("Use --all to remove all quests.")
    n = clear_quests()
    click.echo(f"Removed {n} quest{'s' if n != 1 else ''}.")

@main.command()
@click.argument("difficulty", type=click.Choice(["easy","hard"], case_sensitive=False))
def challenge(difficulty: str):
    base = 2 if difficulty.lower() == "easy" else 10
    xp, level, streak, best = gain_xp(base)
    rewards = roll_challenge_loot(difficulty)
    msg = f"Rick takes on a {difficulty} challenge... 🗡️`nGained {base} XP (+5 streak bonus).`nTotal XP: {xp} | Level: {level} | Streak: {streak} (Best: {best})"
    if rewards:
        msg += "`nRewards: " + "; ".join(rewards)
    click.echo(msg)

@main.command()
def xp():
    d = Storage().load()
    total = d.get("xp", 0)
    level = d.get("level", 1)
    streak = d.get("streak", 0)
    best = d.get("best_streak", 0)
    click.echo(f"XP: {total} | Level: {level}`nStreak: {streak} (Best: {best})")

@main.group()
def inventory():
    """Inventory commands"""

@inventory.command("list")
def inv_cmd_list():
    items, gold = inv_list()
    for it in items:
        click.echo(f"{it.get('name')} x{it.get('qty')} [{it.get('rarity')}]")
    if not items:
        click.echo("(empty)")
    click.echo(f"Gold: {gold}")

@inventory.command("add")
@click.argument("name")
@click.option("--qty", type=int, default=1)
@click.option("--rarity", default="common")
def inv_cmd_add(name: str, qty: int, rarity: str):
    it = inv_add(name, qty, rarity)
    click.echo(f"Added {it['name']} x{qty} [{it['rarity']}]")

@inventory.command("remove")
@click.argument("name")
@click.option("--qty", type=int, default=1)
def inv_cmd_remove(name: str, qty: int):
    ok = inv_remove(name, qty)
    if ok:
        click.echo(f"Removed {name} x{qty}")
    else:
        click.echo(f"Item '{name}' not found.", err=True)
        raise SystemExit(1)

if __name__ == "__main__":
    main()
