# Rick MK2 Changelog

## v0.2.0
- CLI commands now verbose by default:
  - `status` prints streak, bonus, and today’s log entries
  - `log` prints confirmation + updated streak/bonus
- Version bumped to 0.2.0
